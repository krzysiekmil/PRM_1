package pjwstk.s20124.prm_1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import pjwstk.s20124.prm_1.R

class MonthViewActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_month_view)
    }
}